/* 
 * Name: Aditya Varma Vetukuri
 * GNumber: G01213246
 */
#include <stdio.h>
#include <stdlib.h>

#include "node.h"
#include "stack.h"

/* (IMPLEMENT THIS FUNCTION)
 * Create a new Stack_head struct on the Heap and return a pointer to it.
 * Follow the Directions in the Project Documentation for this Function
 * On any malloc errors, return NULL
 */
Stack_head *stack_initialize() {
  /* Implement this function */
  //Allocating memory for the stack
  Stack_head *st = malloc(sizeof(Stack_head));
  if(st==NULL)
  return NULL;
  //Assigning values for stack members
  st->count = 0;
  st->top   = NULL;

  return st;
}

/* (IMPLEMENT THIS FUNCTION)
 * Destroy a stack.
 * Follow the Directions in the Project Documentation for this Function
 * If head is NULL, you can just return.
 */
void stack_destroy(Stack_head *head) {
  // /* Implement this function */
  //Store top of the stack to walker 
   Node *reaper = NULL;
   Node *walker = head->top;
   while(walker!=NULL)
   {
     //delete each node using reaper and iterate walker
     reaper = walker;
     walker = walker->next;
     token_free(reaper->tok);
     free(reaper);
     reaper = NULL;
   }
   node_free(walker);
	free(head);				//Finally,freeing the stack and setting to NULL
	head = NULL;   
  return;
}

/* (IMPLEMENT THIS FUNCTION)
 * Push a new Token on to the Stack.
 * Follow the Directions in the Project Documentation for this Function
 * On any malloc errors, return -1.
 * If there are no errors, return 0.
 */
int stack_push(Stack_head *stack, Token *tok) {
  /* Implement this function */
  //Create the node to push in the stack
  Node *new_node = node_create(tok);
  if(new_node == NULL){
	  node_free(new_node);
  return -1;
  }
  //link our new node to the top of the stack
  new_node->next = stack->top;
  //update top
  stack->top = new_node;
  //increment count
  (stack->count)++;
  return 0;
  }


/* (IMPLEMENT THIS FUNCTION)
 * Pop a Token off of the Stack.
 * Follow the Directions in the Project Documentation for this Function
 * If the stack was empty, return NULL.
 */
Token *stack_pop(Stack_head *stack) {
  /* Implement this function */
  Node *temp = NULL;
  if(stack->top == NULL)
  {
    return NULL;
  }
  //store the top most node in temp
  temp = stack -> top;
  Token *temp_token = NULL;
  //get the token before deleting the node
  temp_token = stack->top->tok;
  //delete node
  free(temp); 
  temp = NULL;
  stack->top = stack->top->next;
  (stack->count)--;
  //return our token
  return temp_token;
}

/* (IMPLEMENT THIS FUNCTION)
 * Return the token in the stack node on the top of the stack
 * Follow the Directions in the Project Documentation for this Function
 * If the stack is NULL, return NULL.
 * If the stack is empty, return NULL.
 */
Token *stack_peek(Stack_head *stack) {
  /* Implement this function */
  if(stack->top != NULL)
  return stack->top->tok;
  else
  return NULL;
}

/* (IMPLEMENT THIS FUNCTION)
 * Return the number of nodes in the stack.
 * Follow the Directions in the Project Documentation for this Function
 * If stack is NULL, return -1.
 * Return 1 if the stack is empty or 0 otherwise.
 */
int stack_is_empty(Stack_head *stack) {
  /* Implement this function */
  if(stack->count==0)
  return 1;
  
  return 0;
}

/* These two functions are written for you.
 * It recurses the stack and prints out the tokens in reverse order
 * eg. top->2->4->1->8 will print at Stack: 8 1 4 2
 * eg. stack_push(5) will then print Stack: 8 1 4 2 5
 */

/* This is implemented for you.
 * Recursive print. (Local function)
 * Base Case: node == NULL, return
 * Recursive Case: call print_node(node->next, print_data), then print node.
 */
static void print_node(Node *node) {
  if(node == NULL) {
    return;
  }
  token_print(node->tok);
  print_node(node->next);
  return;
}

/* This is implemented for you.
 * Setup function for the recursive calls.  Starts printing with stack->top
 */
void stack_print(Stack_head *stack) {
  if(stack == NULL) {
    return;
  }
  printf("|-----Program Stack\n");
  printf("| ");
  print_node(stack->top);
  printf("\n");
  return;
}
